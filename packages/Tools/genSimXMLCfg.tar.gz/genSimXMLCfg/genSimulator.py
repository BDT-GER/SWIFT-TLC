"""Module/script to "compile" all .py files to .pyc (or .pyo) file.

When called as a script with arguments, this compiles the directories
given as arguments recursively; the -l option prevents it from
recursing into directories.

Without arguments, if compiles all modules on sys.path, without
recursing into subdirectories.  (Even though it should do so for
packages -- for now, you'll have to deal with packages separately.)

See module py_compile for details of the actual byte-compilation.

"""

import os
import sys
import ConfigParser

"""
[changer_serial1]
lto6_drive=2
total_slot_num=48
mail_slot_num=1
lto6_tape=2
[changer_serial2]
lto6_drive=2
total_slot_num=48
mail_slot_num=1
lto6_tape=2
"""

def addFileHeader(fSim):
    fSim.write('<?xml version="1.0" encoding="UTF-8" ?>\n')    
    fSim.write('<simulator_conf>\n')
    fSim.write('    <size_for_trigger_read_error>0</size_for_trigger_read_error>\n')
    fSim.write('    <size_for_trigger_write_error>0</size_for_trigger_write_error>\n')
    fSim.write('    <number_of_read_errors>3</number_of_read_errors>\n')
    fSim.write('    <number_of_write_errors>3</number_of_write_errors>\n')
    fSim.write('    <read_delay>0</read_delay>\n')
    fSim.write('    <write_delay>0</write_delay>\n')
    fSim.write('    <move_tape_delay>45</move_tape_delay>\n')
    fSim.write('    <enable_move_tape_failure>0</enable_move_tape_failure>\n')
    fSim.write('    <format_delay>30</format_delay>\n')
    fSim.write('    <enable_format_failure>0</enable_format_failure>\n')
    fSim.write('    <mount_delay>5</mount_delay>\n')
    fSim.write('    <enable_mount_failure>0</enable_mount_failure>\n')
    fSim.write('    <umount_delay>5</umount_delay>\n')
    fSim.write('    <enable_umount_failure>0</enable_umount_failure>\n')
    fSim.write('    <changers>\n')


def addFileEnd(fSim):
    fSim.write('    </changers>\n')
    fSim.write('</simulator_conf>')

def main():
    """Script main program."""
    cf = ConfigParser.ConfigParser()
    cf.read("./simulator.ini")
    
    fSim = open("./simulator.xml", 'w\n');
        
    #add file header
    addFileHeader(fSim)
    
    sections = cf.sections()
    print 'Changer SN:', sections    
    changerIndex = 1
    for sec in sections:
        addChanger(cf, changerIndex, fSim, sec)
        changerIndex += 1
    
    #add file end
    addFileEnd(fSim)
    
    fSim.close()    
    return 0

def addChanger(cf, changerIndex, fSim, section):
    fSim.write('        <changer>\n')
    fSim.write('            <status>1</status>\n')
    fSim.write('            <serial>changer_' + str(changerIndex) + '</serial>\n')
    fSim.write('            <vendor>BDT</vendor>\n')
    fSim.write('            <product>FlexStor II</product>\n')
    fSim.write('            <version>4.80</version>\n')
    fSim.write('            <scsi_addr>changer_' + str(changerIndex) + '</scsi_addr>\n')
    fSim.write('            <stdev>/dev/chh' + str(changerIndex) + '</stdev>\n')
    fSim.write('            <sgdev>/dev/sgh' + str(changerIndex) + '</sgdev>\n')
    fSim.write('            <drives>\n')
    
    lto6_drive= cf.getint(section, "lto6_drive")
    total_slot_num= cf.getint(section, "total_slot_num")
    mail_slot_num= cf.getint(section, "mail_slot_num")
    lto6_tape= cf.getint(section, "lto6_tape")
    for drvIndex in range(1, lto6_drive + 1):
        fSim.write('                <drive>\n')
        fSim.write('                    <status>1</status>\n')
        fSim.write('                    <cleaning_status>1</cleaning_status>\n')
        fSim.write('                    <interface_type>1</interface_type>\n')
        fSim.write('                    <slot_id>' + str(drvIndex) + '</slot_id>\n')
        fSim.write('                    <serial>' + str(changerIndex) + '_drive_' + str(drvIndex) + '</serial>\n')
        fSim.write('                    <vendor>IBM</vendor>\n')
        fSim.write('                    <product>Ultrium 5-SCSI</product>\n')
        fSim.write('                    <version>Z58B</version>\n')
        fSim.write('                    <tape_key></tape_key>\n')
        fSim.write('                    <barcode></barcode>\n')
        fSim.write('                    <scsi_addr>' + str(changerIndex) + '_drive_' + str(drvIndex) + '</scsi_addr>\n')
        fSim.write('                    <stdev>/dev/' + str(changerIndex) + 'st' + str(drvIndex) + '</stdev>\n')
        fSim.write('                    <sgdev>/dev/' + str(changerIndex) + 'sg' + str(drvIndex) + '</sgdev>\n')
        if drvIndex <= lto6_drive:
            fSim.write('                    <generation>6</generation>\n')
        else:
            fSim.write('                    <generation>7</generation>\n')
        fSim.write('                </drive>\n')     
    fSim.write('            </drives>\n')
    
    fSim.write('            <mailslots>\n')
    for iMailSlot in range (1, mail_slot_num + 1):
        fSim.write('                <mailslot>\n')
        fSim.write('                    <slot_id>' + str(100 + iMailSlot) + '</slot_id>\n')
        fSim.write('                    <tape_key></tape_key>\n')
        fSim.write('                    <barcode></barcode>\n')
        fSim.write('                </mailslot>\n')       
    fSim.write('            </mailslots>\n')
    
    fSim.write('            <slots>\n')
    for iSlot in range (1, total_slot_num + 1):
        fSim.write('                <slot>\n')
        fSim.write('                    <slot_id>' + str(1000 + iSlot) + '</slot_id>\n')
        barcode = ""
        tapeKey = ""
        if iSlot <= lto6_tape:
            tapeKey = str(iSlot)
            barcode = "C%dS%dML%d" % (changerIndex, iSlot, 6)
            if iSlot > lto6_tape:
                barcode = "C%dS%dML%d" % (changerIndex, iSlot, 7) 
        fSim.write('                    <tape_key>' + tapeKey + '</tape_key>\n')
        fSim.write('                    <barcode>' + barcode + '</barcode>\n')
        fSim.write('                </slot>\n')
    fSim.write('            </slots>\n')        
    
     
    fSim.write('            <tapes>\n')
    for iTape in range (1, lto6_tape + 1):
        fSim.write('                <tape>\n')
        fSim.write('                    <slot_id>' + str(1000 + iTape) + '</slot_id>\n')
        fSim.write('                    <tape_key>' + str(iTape) + '</tape_key>\n')
        barcode = "C%dS%dML%d" % (changerIndex, iTape, 6)
        media_type = 1
        capacity = 1330737418240
        #capacity = 1000000000000
        if iTape > lto6_tape:
            barcode = "C%dS%dML%d" % (changerIndex, iTape, 7)
            media_type = 7 
            #capacity = 2661474836480 
            capacity = 1330737418240 
        fSim.write('                    <barcode>' + barcode + '</barcode>\n')
        fSim.write('                    <status>1</status>\n')
        fSim.write('                    <medium_type>1</medium_type>\n')
        fSim.write('                    <media_type>' + str(media_type) + '</media_type>\n')
        fSim.write('                    <ltfs_format>0</ltfs_format>\n')
        fSim.write('                    <total_capacity>' + str(capacity) + '</total_capacity>\n')
        fSim.write('                    <group></group>\n')
        fSim.write('                    <dual_copy></dual_copy>\n')
        fSim.write('                    <faulty>false</faulty>\n')
        fSim.write('                    <generation_index>0</generation_index>\n')
        fSim.write('                </tape>\n')
    fSim.write('            </tapes>\n')  
    fSim.write('        </changer>\n')  

if __name__ == '__main__':
    exit_status = main()
    sys.exit(exit_status)
